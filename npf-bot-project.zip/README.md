# npf-bot-project
Telegram-бот с PostgreSQL
Инструкция внутри